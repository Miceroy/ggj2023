<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Kainuu map" tilewidth="64" tileheight="64" tilecount="182" columns="13">
 <image source="../../kainuu.png" width="852" height="938"/>
</tileset>
