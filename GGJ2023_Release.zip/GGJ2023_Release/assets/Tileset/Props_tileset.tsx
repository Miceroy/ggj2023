<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Props_tileset" tilewidth="64" tileheight="64" tilecount="256" columns="16">
 <image source="props.png" width="1024" height="1024"/>
</tileset>
