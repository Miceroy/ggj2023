<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Map_tileset" tilewidth="64" tileheight="64" tilecount="300" columns="30">
 <image source="Tileset.png" width="1920" height="640"/>
 <tile id="30">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="4" y="50" width="60" height="14"/>
  </objectgroup>
 </tile>
 <tile id="31">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="50" width="64" height="14"/>
  </objectgroup>
 </tile>
 <tile id="32">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="50" width="60" height="14"/>
  </objectgroup>
 </tile>
 <tile id="33">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="4" y="50" width="56" height="14"/>
  </objectgroup>
 </tile>
 <tile id="34">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="4" y="50" width="56" height="14"/>
  </objectgroup>
 </tile>
 <tile id="35">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="2" y="52" width="62" height="12"/>
  </objectgroup>
 </tile>
 <tile id="36">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="52" width="64" height="12"/>
  </objectgroup>
 </tile>
 <tile id="37">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="52" width="60" height="12"/>
  </objectgroup>
 </tile>
 <tile id="38">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="2" y="52" width="58" height="12"/>
  </objectgroup>
 </tile>
 <tile id="39">
  <objectgroup draworder="index" id="2">
   <object id="4" name="BoundingBox" class="BoundingBox" x="2" y="52" width="58" height="12"/>
  </objectgroup>
 </tile>
 <tile id="41">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="4" y="50" width="60" height="14"/>
  </objectgroup>
 </tile>
 <tile id="42">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="50" width="60" height="14"/>
  </objectgroup>
 </tile>
 <tile id="44">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="64" height="64"/>
  </objectgroup>
 </tile>
 <tile id="45">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="62" height="64"/>
  </objectgroup>
 </tile>
 <tile id="47">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="2" y="52" width="62" height="12"/>
  </objectgroup>
 </tile>
 <tile id="48">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="52" width="60" height="12"/>
  </objectgroup>
 </tile>
 <tile id="60">
  <objectgroup draworder="index" id="2">
   <object id="2" name="BoundingBox" class="BoundingBox" x="2" y="0" width="62" height="64"/>
  </objectgroup>
 </tile>
 <tile id="61">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="64" height="64"/>
  </objectgroup>
 </tile>
 <tile id="62">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="62" height="64"/>
  </objectgroup>
 </tile>
 <tile id="63">
  <objectgroup draworder="index" id="2">
   <object id="2" name="BoundingBox" class="BoundingBox" x="2" y="0" width="60" height="64"/>
  </objectgroup>
 </tile>
 <tile id="64">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="2" y="0" width="60" height="42"/>
  </objectgroup>
 </tile>
 <tile id="65">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="2" y="0" width="62" height="64"/>
  </objectgroup>
 </tile>
 <tile id="66">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="64" height="64"/>
  </objectgroup>
 </tile>
 <tile id="67">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="62" height="64"/>
  </objectgroup>
 </tile>
 <tile id="68">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="2" y="0" width="60" height="64"/>
  </objectgroup>
 </tile>
 <tile id="72">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="62" height="64"/>
  </objectgroup>
 </tile>
 <tile id="74">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="64" height="64"/>
  </objectgroup>
 </tile>
 <tile id="75">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="62" height="64"/>
  </objectgroup>
 </tile>
 <tile id="77">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="2" y="0" width="62" height="64"/>
  </objectgroup>
 </tile>
 <tile id="78">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="62" height="64"/>
  </objectgroup>
 </tile>
 <tile id="90">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="2" y="0" width="62" height="64"/>
  </objectgroup>
 </tile>
 <tile id="91">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="64" height="64"/>
  </objectgroup>
 </tile>
 <tile id="92">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="62" height="64"/>
  </objectgroup>
 </tile>
 <tile id="93">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="2" y="0" width="60" height="64"/>
  </objectgroup>
 </tile>
 <tile id="95">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="2" y="0" width="62" height="64"/>
  </objectgroup>
 </tile>
 <tile id="96">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="64" height="64"/>
  </objectgroup>
 </tile>
 <tile id="97">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="62" height="64"/>
  </objectgroup>
 </tile>
 <tile id="98">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="2" y="0" width="60" height="64"/>
  </objectgroup>
 </tile>
 <tile id="100">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="4" y="50" width="60" height="14"/>
  </objectgroup>
 </tile>
 <tile id="101">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="64" height="64"/>
  </objectgroup>
 </tile>
 <tile id="102">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="64" height="64"/>
  </objectgroup>
 </tile>
 <tile id="106">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="2" y="52" width="62" height="12"/>
  </objectgroup>
 </tile>
 <tile id="107">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="64" height="64"/>
  </objectgroup>
 </tile>
 <tile id="108">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="64" height="64"/>
  </objectgroup>
 </tile>
 <tile id="109">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="52" width="60" height="12"/>
  </objectgroup>
 </tile>
 <tile id="120">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="2" y="0" width="62" height="42"/>
  </objectgroup>
 </tile>
 <tile id="121">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="64" height="42"/>
  </objectgroup>
 </tile>
 <tile id="122">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="62" height="42"/>
  </objectgroup>
 </tile>
 <tile id="123">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="2" y="0" width="60" height="42"/>
  </objectgroup>
 </tile>
 <tile id="125">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="2" y="0" width="62" height="42"/>
  </objectgroup>
 </tile>
 <tile id="126">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="64" height="42"/>
  </objectgroup>
 </tile>
 <tile id="127">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="62" height="42"/>
  </objectgroup>
 </tile>
 <tile id="128">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="2" y="0" width="60" height="42"/>
  </objectgroup>
 </tile>
 <tile id="130">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="2" y="0" width="62" height="64"/>
  </objectgroup>
 </tile>
 <tile id="136">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="2" y="0" width="62" height="64"/>
  </objectgroup>
 </tile>
 <tile id="137">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="64" height="64"/>
  </objectgroup>
 </tile>
 <tile id="138">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="64" height="64"/>
  </objectgroup>
 </tile>
 <tile id="139">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="62" height="64"/>
  </objectgroup>
 </tile>
 <tile id="156">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="14" width="64" height="50"/>
  </objectgroup>
 </tile>
 <tile id="157">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="14" width="64" height="50"/>
  </objectgroup>
 </tile>
 <tile id="158">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="8" y="0" width="48" height="64"/>
  </objectgroup>
 </tile>
 <tile id="160">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="2" y="0" width="62" height="42"/>
  </objectgroup>
 </tile>
 <tile id="161">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="64" height="64"/>
  </objectgroup>
 </tile>
 <tile id="162">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="64" height="64"/>
  </objectgroup>
 </tile>
 <tile id="163">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="62" height="42"/>
  </objectgroup>
 </tile>
 <tile id="166">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="2" y="0" width="62" height="42"/>
  </objectgroup>
 </tile>
 <tile id="167">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="64" height="64"/>
  </objectgroup>
 </tile>
 <tile id="168">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="64" height="64"/>
  </objectgroup>
 </tile>
 <tile id="169">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="62" height="42"/>
  </objectgroup>
 </tile>
 <tile id="186">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="64" height="64"/>
  </objectgroup>
 </tile>
 <tile id="187">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="64" height="64"/>
  </objectgroup>
 </tile>
 <tile id="188">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="8" y="0" width="48" height="64"/>
  </objectgroup>
 </tile>
 <tile id="191">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="2" y="0" width="62" height="64"/>
  </objectgroup>
 </tile>
 <tile id="192">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="62" height="64"/>
  </objectgroup>
 </tile>
 <tile id="197">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="2" y="0" width="62" height="64"/>
  </objectgroup>
 </tile>
 <tile id="198">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="62" height="64"/>
  </objectgroup>
 </tile>
 <tile id="214">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="16" y="20" width="34" height="38"/>
  </objectgroup>
 </tile>
 <tile id="216">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="64" height="64"/>
  </objectgroup>
 </tile>
 <tile id="217">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="64" height="64"/>
  </objectgroup>
 </tile>
 <tile id="218">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="8" y="0" width="48" height="64"/>
  </objectgroup>
 </tile>
 <tile id="221">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="2" y="0" width="62" height="42"/>
  </objectgroup>
 </tile>
 <tile id="222">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="62" height="42"/>
  </objectgroup>
 </tile>
 <tile id="227">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="2" y="0" width="62" height="42"/>
  </objectgroup>
 </tile>
 <tile id="228">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="0" y="0" width="62" height="42"/>
  </objectgroup>
 </tile>
 <tile id="248">
  <objectgroup draworder="index" id="2">
   <object id="1" name="BoundingBox" class="BoundingBox" x="8" y="0" width="48" height="62"/>
  </objectgroup>
 </tile>
 <tile id="255">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="64" height="64"/>
  </objectgroup>
 </tile>
</tileset>
